import React from 'react';
import Principal from './pages/Principal';
import './global.css'

function App() {
  return (
    <Principal />    
  );
}

export default App;
