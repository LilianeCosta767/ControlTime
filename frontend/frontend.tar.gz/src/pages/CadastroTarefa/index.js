import React from 'react';
import './styles.css';

export default function CadastroTarefa() {
    return(
        <h1>Testando CadastroTarefa</h1>
    );
}